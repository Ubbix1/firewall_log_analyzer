package androidx.window;

public final class R {

    public static final class attr {
        public static final int activityAction = 2130771968;
        public static final int activityName = 2130771969;
        public static final int alwaysExpand = 2130771971;
        public static final int clearTop = 2130771972;
        public static final int finishPrimaryWithSecondary = 2130771973;
        public static final int finishSecondaryWithPrimary = 2130771974;
        public static final int placeholderActivityName = 2130771987;
        public static final int primaryActivityName = 2130771988;
        public static final int secondaryActivityAction = 2130771990;
        public static final int secondaryActivityName = 2130771991;
        public static final int splitLayoutDirection = 2130771993;
        public static final int splitMinSmallestWidth = 2130771994;
        public static final int splitMinWidth = 2130771995;
        public static final int splitRatio = 2130771996;

        private attr() {
        }
    }

    public static final class id {
        public static final int androidx_window_activity_scope = 2131034150;
        public static final int locale = 2131034162;
        public static final int ltr = 2131034163;
        public static final int rtl = 2131034170;

        private id() {
        }
    }

    public static final class styleable {
        public static final int[] ActivityFilter = {com.example.firewall_log_analyzer.R.attr.activityAction, com.example.firewall_log_analyzer.R.attr.activityName};
        public static final int ActivityFilter_activityAction = 0;
        public static final int ActivityFilter_activityName = 1;
        public static final int[] ActivityRule = {com.example.firewall_log_analyzer.R.attr.alwaysExpand};
        public static final int ActivityRule_alwaysExpand = 0;
        public static final int[] SplitPairFilter = {com.example.firewall_log_analyzer.R.attr.primaryActivityName, com.example.firewall_log_analyzer.R.attr.secondaryActivityAction, com.example.firewall_log_analyzer.R.attr.secondaryActivityName};
        public static final int SplitPairFilter_primaryActivityName = 0;
        public static final int SplitPairFilter_secondaryActivityAction = 1;
        public static final int SplitPairFilter_secondaryActivityName = 2;
        public static final int[] SplitPairRule = {com.example.firewall_log_analyzer.R.attr.clearTop, com.example.firewall_log_analyzer.R.attr.finishPrimaryWithSecondary, com.example.firewall_log_analyzer.R.attr.finishSecondaryWithPrimary, com.example.firewall_log_analyzer.R.attr.splitLayoutDirection, com.example.firewall_log_analyzer.R.attr.splitMinSmallestWidth, com.example.firewall_log_analyzer.R.attr.splitMinWidth, com.example.firewall_log_analyzer.R.attr.splitRatio};
        public static final int SplitPairRule_clearTop = 0;
        public static final int SplitPairRule_finishPrimaryWithSecondary = 1;
        public static final int SplitPairRule_finishSecondaryWithPrimary = 2;
        public static final int SplitPairRule_splitLayoutDirection = 3;
        public static final int SplitPairRule_splitMinSmallestWidth = 4;
        public static final int SplitPairRule_splitMinWidth = 5;
        public static final int SplitPairRule_splitRatio = 6;
        public static final int[] SplitPlaceholderRule = {com.example.firewall_log_analyzer.R.attr.placeholderActivityName, com.example.firewall_log_analyzer.R.attr.splitLayoutDirection, com.example.firewall_log_analyzer.R.attr.splitMinSmallestWidth, com.example.firewall_log_analyzer.R.attr.splitMinWidth, com.example.firewall_log_analyzer.R.attr.splitRatio};
        public static final int SplitPlaceholderRule_placeholderActivityName = 0;
        public static final int SplitPlaceholderRule_splitLayoutDirection = 1;
        public static final int SplitPlaceholderRule_splitMinSmallestWidth = 2;
        public static final int SplitPlaceholderRule_splitMinWidth = 3;
        public static final int SplitPlaceholderRule_splitRatio = 4;

        private styleable() {
        }
    }

    private R() {
    }
}
