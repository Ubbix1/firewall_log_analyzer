package androidx.window.embedding;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class ActivityRule$$ExternalSyntheticBackport0 {
    public static /* synthetic */ int m(boolean z) {
        return z ? 1231 : 1237;
    }
}
