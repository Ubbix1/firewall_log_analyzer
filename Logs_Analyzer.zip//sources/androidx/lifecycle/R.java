package androidx.lifecycle;

public final class R {
    private R() {
    }
}
