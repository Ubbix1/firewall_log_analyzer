package androidx.core.util;

public interface Supplier<T> {
    T get();
}
