package androidx.core.view;

public interface OnReceiveContentViewBehavior {
    ContentInfoCompat onReceiveContent(ContentInfoCompat contentInfoCompat);
}
