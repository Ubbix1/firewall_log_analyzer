package androidx.core.view;

import android.view.View;

public interface OnReceiveContentListener {
    ContentInfoCompat onReceiveContent(View view, ContentInfoCompat contentInfoCompat);
}
