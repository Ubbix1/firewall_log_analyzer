package androidx.core.widget;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class ContentLoadingProgressBar$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ ContentLoadingProgressBar f$0;

    public /* synthetic */ ContentLoadingProgressBar$$ExternalSyntheticLambda3(ContentLoadingProgressBar contentLoadingProgressBar) {
        this.f$0 = contentLoadingProgressBar;
    }

    public final void run() {
        this.f$0.m2lambda$new$1$androidxcorewidgetContentLoadingProgressBar();
    }
}
