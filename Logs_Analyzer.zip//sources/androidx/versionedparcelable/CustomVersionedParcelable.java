package androidx.versionedparcelable;

public abstract class CustomVersionedParcelable implements VersionedParcelable {
    public void onPostParceling() {
    }

    public void onPreParceling(boolean z) {
    }
}
