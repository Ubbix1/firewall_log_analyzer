package androidx.versionedparcelable;

public interface VersionedParcelable {
}
