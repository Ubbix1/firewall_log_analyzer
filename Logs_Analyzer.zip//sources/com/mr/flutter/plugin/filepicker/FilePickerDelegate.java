package com.mr.flutter.plugin.filepicker;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.util.Log;
import androidx.core.app.ActivityCompat;
import androidx.core.internal.view.SupportMenu;
import io.flutter.plugin.common.EventChannel;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.PluginRegistry;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;

public class FilePickerDelegate implements PluginRegistry.ActivityResultListener, PluginRegistry.RequestPermissionsResultListener {
    private static final int REQUEST_CODE = ((FilePickerPlugin.class.hashCode() + 43) & SupportMenu.USER_MASK);
    private static final int SAVE_FILE_CODE = ((FilePickerPlugin.class.hashCode() + 83) & SupportMenu.USER_MASK);
    private static final String TAG = "FilePickerDelegate";
    /* access modifiers changed from: private */
    public final Activity activity;
    private String[] allowedExtensions;
    private byte[] bytes;
    /* access modifiers changed from: private */
    public int compressionQuality;
    /* access modifiers changed from: private */
    public EventChannel.EventSink eventSink;
    private boolean isMultipleSelection;
    /* access modifiers changed from: private */
    public boolean loadDataToMemory;
    private MethodChannel.Result pendingResult;
    private final PermissionManager permissionManager;
    /* access modifiers changed from: private */
    public String type;

    interface PermissionManager {
        void askForPermission(String str, int i);

        boolean isPermissionGranted(String str);
    }

    public FilePickerDelegate(final Activity activity2) {
        this(activity2, (MethodChannel.Result) null, new PermissionManager() {
            public boolean isPermissionGranted(String str) {
                return ActivityCompat.checkSelfPermission(activity2, str) == 0;
            }

            public void askForPermission(String str, int i) {
                ActivityCompat.requestPermissions(activity2, new String[]{str}, i);
            }
        });
    }

    public void setEventHandler(EventChannel.EventSink eventSink2) {
        this.eventSink = eventSink2;
    }

    FilePickerDelegate(Activity activity2, MethodChannel.Result result, PermissionManager permissionManager2) {
        this.isMultipleSelection = false;
        this.loadDataToMemory = false;
        this.compressionQuality = 20;
        this.activity = activity2;
        this.pendingResult = result;
        this.permissionManager = permissionManager2;
    }

    public boolean onActivityResult(int i, int i2, final Intent intent) {
        if (i == SAVE_FILE_CODE) {
            if (i2 == -1) {
                dispatchEventStatus(true);
                Uri data = intent.getData();
                if (data != null) {
                    String str = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() + File.separator + FileUtils.getFileName(data, this.activity);
                    try {
                        OutputStream openOutputStream = this.activity.getContentResolver().openOutputStream(data);
                        if (openOutputStream != null) {
                            openOutputStream.write(this.bytes);
                            openOutputStream.flush();
                            openOutputStream.close();
                        }
                        finishWithSuccess(str);
                        return true;
                    } catch (IOException e) {
                        Log.i(TAG, "Error while saving file", e);
                        finishWithError("Error while saving file", e.getMessage());
                    }
                }
            }
            if (i2 == 0) {
                Log.i(TAG, "User cancelled the save request");
                finishWithSuccess((Object) null);
            }
            return false;
        } else if (this.type == null) {
            return false;
        } else {
            int i3 = REQUEST_CODE;
            if (i == i3 && i2 == -1) {
                dispatchEventStatus(true);
                new Thread(new Runnable() {
                    /* JADX WARNING: Code restructure failed: missing block: B:49:0x019a, code lost:
                        r2 = (android.net.Uri) r2;
                     */
                    /* Code decompiled incorrectly, please refer to instructions dump. */
                    public void run() {
                        /*
                            r10 = this;
                            android.content.Intent r0 = r9
                            java.lang.String r1 = "Unknown activity error, please fill an issue."
                            java.lang.String r2 = "unknown_activity"
                            if (r0 == 0) goto L_0x01e4
                            java.util.ArrayList r0 = new java.util.ArrayList
                            r0.<init>()
                            android.content.Intent r3 = r9
                            android.content.ClipData r3 = r3.getClipData()
                            java.lang.String r4 = " - URI: "
                            java.lang.String r5 = "[MultiFilePick] File #"
                            java.lang.String r6 = "image/*"
                            r7 = 0
                            java.lang.String r8 = "FilePickerDelegate"
                            if (r3 == 0) goto L_0x009b
                            android.content.Intent r1 = r9
                            android.content.ClipData r1 = r1.getClipData()
                            int r1 = r1.getItemCount()
                        L_0x0028:
                            if (r7 >= r1) goto L_0x0094
                            android.content.Intent r2 = r9
                            android.content.ClipData r2 = r2.getClipData()
                            android.content.ClipData$Item r2 = r2.getItemAt(r7)
                            android.net.Uri r2 = r2.getUri()
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r3 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            java.lang.String r3 = r3.type
                            boolean r3 = java.util.Objects.equals(r3, r6)
                            if (r3 == 0) goto L_0x0060
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r3 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            int r3 = r3.compressionQuality
                            if (r3 <= 0) goto L_0x0060
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r3 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            int r3 = r3.compressionQuality
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r9 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            android.app.Activity r9 = r9.activity
                            android.content.Context r9 = r9.getApplicationContext()
                            android.net.Uri r2 = com.mr.flutter.plugin.filepicker.FileUtils.compressImage(r2, r3, r9)
                        L_0x0060:
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r3 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            android.app.Activity r3 = r3.activity
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r9 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            boolean r9 = r9.loadDataToMemory
                            com.mr.flutter.plugin.filepicker.FileInfo r3 = com.mr.flutter.plugin.filepicker.FileUtils.openFileStream(r3, r2, r9)
                            if (r3 == 0) goto L_0x0091
                            r0.add(r3)
                            java.lang.StringBuilder r3 = new java.lang.StringBuilder
                            r3.<init>()
                            r3.append(r5)
                            r3.append(r7)
                            r3.append(r4)
                            java.lang.String r2 = r2.getPath()
                            r3.append(r2)
                            java.lang.String r2 = r3.toString()
                            android.util.Log.d(r8, r2)
                        L_0x0091:
                            int r7 = r7 + 1
                            goto L_0x0028
                        L_0x0094:
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r1 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            r1.finishWithSuccess(r0)
                            goto L_0x01e9
                        L_0x009b:
                            android.content.Intent r3 = r9
                            android.net.Uri r3 = r3.getData()
                            java.lang.String r9 = "unknown_path"
                            if (r3 == 0) goto L_0x0164
                            android.content.Intent r1 = r9
                            android.net.Uri r1 = r1.getData()
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r2 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            java.lang.String r2 = r2.type
                            boolean r2 = java.util.Objects.equals(r2, r6)
                            if (r2 == 0) goto L_0x00d3
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r2 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            int r2 = r2.compressionQuality
                            if (r2 <= 0) goto L_0x00d3
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r2 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            int r2 = r2.compressionQuality
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r3 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            android.app.Activity r3 = r3.activity
                            android.content.Context r3 = r3.getApplicationContext()
                            android.net.Uri r1 = com.mr.flutter.plugin.filepicker.FileUtils.compressImage(r1, r2, r3)
                        L_0x00d3:
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r2 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            java.lang.String r2 = r2.type
                            java.lang.String r3 = "dir"
                            boolean r2 = r2.equals(r3)
                            if (r2 == 0) goto L_0x0121
                            int r2 = android.os.Build.VERSION.SDK_INT
                            r3 = 21
                            if (r2 < r3) goto L_0x0121
                            java.lang.String r0 = android.provider.DocumentsContract.getTreeDocumentId(r1)
                            android.net.Uri r0 = android.provider.DocumentsContract.buildDocumentUriUsingTree(r1, r0)
                            java.lang.StringBuilder r1 = new java.lang.StringBuilder
                            r1.<init>()
                            java.lang.String r2 = "[SingleFilePick] File URI:"
                            r1.append(r2)
                            java.lang.String r2 = r0.toString()
                            r1.append(r2)
                            java.lang.String r1 = r1.toString()
                            android.util.Log.d(r8, r1)
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r1 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            android.app.Activity r1 = r1.activity
                            java.lang.String r0 = com.mr.flutter.plugin.filepicker.FileUtils.getFullPathFromTreeUri(r0, r1)
                            if (r0 == 0) goto L_0x0119
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r1 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            r1.finishWithSuccess(r0)
                            goto L_0x0120
                        L_0x0119:
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r0 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            java.lang.String r1 = "Failed to retrieve directory path."
                            r0.finishWithError(r9, r1)
                        L_0x0120:
                            return
                        L_0x0121:
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r2 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            android.app.Activity r2 = r2.activity
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r3 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            boolean r3 = r3.loadDataToMemory
                            com.mr.flutter.plugin.filepicker.FileInfo r1 = com.mr.flutter.plugin.filepicker.FileUtils.openFileStream(r2, r1, r3)
                            if (r1 == 0) goto L_0x0136
                            r0.add(r1)
                        L_0x0136:
                            boolean r1 = r0.isEmpty()
                            if (r1 != 0) goto L_0x015b
                            java.lang.StringBuilder r1 = new java.lang.StringBuilder
                            r1.<init>()
                            java.lang.String r2 = "File path:"
                            r1.append(r2)
                            java.lang.String r2 = r0.toString()
                            r1.append(r2)
                            java.lang.String r1 = r1.toString()
                            android.util.Log.d(r8, r1)
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r1 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            r1.finishWithSuccess(r0)
                            goto L_0x01e9
                        L_0x015b:
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r0 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            java.lang.String r1 = "Failed to retrieve path."
                            r0.finishWithError(r9, r1)
                            goto L_0x01e9
                        L_0x0164:
                            android.content.Intent r3 = r9
                            android.os.Bundle r3 = r3.getExtras()
                            if (r3 == 0) goto L_0x01de
                            android.content.Intent r1 = r9
                            android.os.Bundle r1 = r1.getExtras()
                            java.util.Set r2 = r1.keySet()
                            java.lang.String r3 = "selectedItems"
                            boolean r2 = r2.contains(r3)
                            if (r2 == 0) goto L_0x01d6
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r2 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            java.util.ArrayList r1 = r2.getSelectedItems(r1)
                            if (r1 == 0) goto L_0x01d0
                            java.util.Iterator r1 = r1.iterator()
                        L_0x018a:
                            boolean r2 = r1.hasNext()
                            if (r2 == 0) goto L_0x01d0
                            java.lang.Object r2 = r1.next()
                            android.os.Parcelable r2 = (android.os.Parcelable) r2
                            boolean r3 = r2 instanceof android.net.Uri
                            if (r3 == 0) goto L_0x01cd
                            android.net.Uri r2 = (android.net.Uri) r2
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r3 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            android.app.Activity r3 = r3.activity
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r6 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            boolean r6 = r6.loadDataToMemory
                            com.mr.flutter.plugin.filepicker.FileInfo r3 = com.mr.flutter.plugin.filepicker.FileUtils.openFileStream(r3, r2, r6)
                            if (r3 == 0) goto L_0x01cd
                            r0.add(r3)
                            java.lang.StringBuilder r3 = new java.lang.StringBuilder
                            r3.<init>()
                            r3.append(r5)
                            r3.append(r7)
                            r3.append(r4)
                            java.lang.String r2 = r2.getPath()
                            r3.append(r2)
                            java.lang.String r2 = r3.toString()
                            android.util.Log.d(r8, r2)
                        L_0x01cd:
                            int r7 = r7 + 1
                            goto L_0x018a
                        L_0x01d0:
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r1 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            r1.finishWithSuccess(r0)
                            goto L_0x01e9
                        L_0x01d6:
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r0 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            java.lang.String r1 = "Failed to retrieve path from bundle."
                            r0.finishWithError(r9, r1)
                            goto L_0x01e9
                        L_0x01de:
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r0 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            r0.finishWithError(r2, r1)
                            goto L_0x01e9
                        L_0x01e4:
                            com.mr.flutter.plugin.filepicker.FilePickerDelegate r0 = com.mr.flutter.plugin.filepicker.FilePickerDelegate.this
                            r0.finishWithError(r2, r1)
                        L_0x01e9:
                            return
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.mr.flutter.plugin.filepicker.FilePickerDelegate.AnonymousClass2.run():void");
                    }
                }).start();
                return true;
            } else if (i == i3 && i2 == 0) {
                Log.i(TAG, "User cancelled the picker request");
                finishWithSuccess((Object) null);
                return true;
            } else {
                if (i == i3) {
                    finishWithError("unknown_activity", "Unknown activity error, please fill an issue.");
                }
                return false;
            }
        }
    }

    public boolean onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        boolean z = false;
        if (REQUEST_CODE != i) {
            return false;
        }
        if (iArr.length > 0 && iArr[0] == 0) {
            z = true;
        }
        if (z) {
            startFileExplorer();
        } else {
            finishWithError("read_external_storage_denied", "User did not allow reading external storage");
        }
        return true;
    }

    private boolean setPendingMethodCallAndResult(MethodChannel.Result result) {
        if (this.pendingResult != null) {
            return false;
        }
        this.pendingResult = result;
        return true;
    }

    private static void finishWithAlreadyActiveError(MethodChannel.Result result) {
        result.error("already_active", "File picker is already active", (Object) null);
    }

    /* access modifiers changed from: private */
    public ArrayList<Parcelable> getSelectedItems(Bundle bundle) {
        if (Build.VERSION.SDK_INT >= 33) {
            return bundle.getParcelableArrayList("selectedItems", Parcelable.class);
        }
        return bundle.getParcelableArrayList("selectedItems");
    }

    private void startFileExplorer() {
        Intent intent;
        String str = this.type;
        if (str != null) {
            if (str.equals("dir")) {
                intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
            } else {
                if (this.type.equals("image/*")) {
                    intent = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                } else {
                    intent = new Intent("android.intent.action.GET_CONTENT");
                    intent.addCategory("android.intent.category.OPENABLE");
                }
                Uri parse = Uri.parse(Environment.getExternalStorageDirectory().getPath() + File.separator);
                Log.d(TAG, "Selected type " + this.type);
                intent.setDataAndType(parse, this.type);
                intent.setType(this.type);
                intent.putExtra("android.intent.extra.ALLOW_MULTIPLE", this.isMultipleSelection);
                intent.putExtra("multi-pick", this.isMultipleSelection);
                if (this.type.contains(",")) {
                    this.allowedExtensions = this.type.split(",");
                }
                String[] strArr = this.allowedExtensions;
                if (strArr != null) {
                    intent.putExtra("android.intent.extra.MIME_TYPES", strArr);
                }
            }
            if (intent.resolveActivity(this.activity.getPackageManager()) != null) {
                this.activity.startActivityForResult(Intent.createChooser(intent, (CharSequence) null), REQUEST_CODE);
                return;
            }
            Log.e(TAG, "Can't find a valid activity to handle the request. Make sure you've a file explorer installed.");
            finishWithError("invalid_format_type", "Can't handle the provided file type.");
        }
    }

    public void startFileExplorer(String str, boolean z, boolean z2, String[] strArr, int i, MethodChannel.Result result) {
        if (!setPendingMethodCallAndResult(result)) {
            finishWithAlreadyActiveError(result);
            return;
        }
        this.type = str;
        this.isMultipleSelection = z;
        this.loadDataToMemory = z2;
        this.allowedExtensions = strArr;
        this.compressionQuality = i;
        if (Build.VERSION.SDK_INT >= 33 || this.permissionManager.isPermissionGranted("android.permission.READ_EXTERNAL_STORAGE")) {
            startFileExplorer();
        } else {
            this.permissionManager.askForPermission("android.permission.READ_EXTERNAL_STORAGE", REQUEST_CODE);
        }
    }

    public void saveFile(String str, String str2, String str3, String[] strArr, byte[] bArr, MethodChannel.Result result) {
        if (!setPendingMethodCallAndResult(result)) {
            finishWithAlreadyActiveError(result);
            return;
        }
        Intent intent = new Intent("android.intent.action.CREATE_DOCUMENT");
        intent.addCategory("android.intent.category.OPENABLE");
        if (str != null && !str.isEmpty()) {
            intent.putExtra("android.intent.extra.TITLE", str);
        }
        this.bytes = bArr;
        if (str2 == null || "dir".equals(str2) || str2.split(",").length != 1) {
            intent.setType("*/*");
        } else {
            intent.setType(str2);
        }
        if (str3 != null && !str3.isEmpty() && Build.VERSION.SDK_INT >= 26) {
            intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse(str3));
        }
        if (strArr != null && strArr.length > 0) {
            intent.putExtra("android.intent.extra.MIME_TYPES", strArr);
        }
        if (intent.resolveActivity(this.activity.getPackageManager()) != null) {
            this.activity.startActivityForResult(intent, SAVE_FILE_CODE);
            return;
        }
        Log.e(TAG, "Can't find a valid activity to handle the request. Make sure you've a file explorer installed.");
        finishWithError("invalid_format_type", "Can't handle the provided file type.");
    }

    /* access modifiers changed from: private */
    public void finishWithSuccess(Object obj) {
        dispatchEventStatus(false);
        if (this.pendingResult != null) {
            if (obj != null && !(obj instanceof String)) {
                ArrayList arrayList = new ArrayList();
                Iterator it = ((ArrayList) obj).iterator();
                while (it.hasNext()) {
                    arrayList.add(((FileInfo) it.next()).toMap());
                }
                obj = arrayList;
            }
            this.pendingResult.success(obj);
            clearPendingResult();
        }
    }

    /* access modifiers changed from: private */
    public void finishWithError(String str, String str2) {
        if (this.pendingResult != null) {
            dispatchEventStatus(false);
            this.pendingResult.error(str, str2, (Object) null);
            clearPendingResult();
        }
    }

    private void dispatchEventStatus(final boolean z) {
        if (this.eventSink != null && !this.type.equals("dir")) {
            new Handler(Looper.getMainLooper()) {
                public void handleMessage(Message message) {
                    FilePickerDelegate.this.eventSink.success(Boolean.valueOf(z));
                }
            }.obtainMessage().sendToTarget();
        }
    }

    private void clearPendingResult() {
        this.pendingResult = null;
    }
}
