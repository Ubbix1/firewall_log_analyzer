package com.example.firewall_log_analyzer;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.example.firewall_log_analyzer";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.0.0";
}
