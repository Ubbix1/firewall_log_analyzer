package com.example.firewall_log_analyzer;

import io.flutter.embedding.android.FlutterActivity;
import kotlin.Metadata;

@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Lcom/example/firewall_log_analyzer/MainActivity;", "Lio/flutter/embedding/android/FlutterActivity;", "()V", "app_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
/* compiled from: MainActivity.kt */
public final class MainActivity extends FlutterActivity {
}
